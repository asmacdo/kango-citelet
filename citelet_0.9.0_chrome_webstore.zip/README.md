kango-citelet
=============

Tool for extracting metadata from scholarlay journal articles from browser activity. These are the common files that kango builds into extensions for firefox, chrome, and safari.

To build, install kango and create a new project. Place the files from this repo (minus the output folder) into the src/common directory. Build the files and install the appropriate file from the output directory.
