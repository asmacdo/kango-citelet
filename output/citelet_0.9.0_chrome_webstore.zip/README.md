kango-citelet
=============

Tool for extracting metadata from scholarlay journal articles from browser activity. These are the common files that kango builds into extensions for firefox, chrome, and safari.

